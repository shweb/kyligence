<table class="vc_table vc_column-offset-table">

    <tr class="vc_size-lg">
        <td class="vc_screen-size-lg">
            {{field}}
        </td>
        <td>
            {{field}}
        </td>
    </tr>
    <tr class="vc_size-md">
        <td class="vc_screen-size-lg">
            {{field}}
        </td>
        <td>
            {{field}}
        </td>
    </tr>
    <tr class="vc_size-md">
        <td class="vc_screen-size-md" colspan="2">
            {{field}}
        </td>          
    </tr>
</table>