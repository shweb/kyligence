<table class="vc_table vc_column-offset-table">
    <tr class="vc_size-lg">
        <td class="vc_screen-size-lg">
            {{field}}
        </td>
        <td class="vc_screen-size-lg">
            {{field}}
        </td>
    </tr>
    <tr class="vc_size-md">
        <td class="vc_screen-size-lg" colspan="2">
            {{field}}
        </td>
    </tr>
</table>