
{{hidden}}
<div class="box">
    <p class="dfd-half-size border-right border-bottom padding-left">
        <span class="wpcf7-form-control-wrap ">
            {{field}}
        </span> 
    </p>
    <p class="dfd-half-size margin-left-1 border-bottom padding-right">
        <span class="wpcf7-form-control-wrap ">
            {{field}}
        </span>
    </p>
    <div class="clear"></div>
    <p class="dfd-half-size border-right  border-bottom padding-left">
        <span class="wpcf7-form-control-wrap ">
            {{field}}
        </span>
    </p>
    <p class="dfd-half-size border-bottom margin-left-1 padding-right">
        <span class="wpcf7-form-control-wrap">
            {{field}}
        </span>
    </p>
    <div class="clear"></div>

    <p class="border-bottom last">
        <span class="wpcf7-form-control-wrap">
            {{field}}
        </span>
    </p>   
    <div class="clear"></div>


</div>




