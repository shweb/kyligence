<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
Heading style
*/
$output .= '<div class="title-wrap">';
$output .= $delimiter_html;
$output .= $title_html;
$output .= '</div>';
$output .= $subtitle_html;