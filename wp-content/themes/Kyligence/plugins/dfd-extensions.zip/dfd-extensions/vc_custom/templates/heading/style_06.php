<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
Heading style
*/
$output .= $subtitle_html;
$output .= $delimiter_html;
$output .= $title_html;