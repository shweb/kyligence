<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
Heading style
*/
$output .= $title_html;
$output .= $subtitle_html;
$output .= $delimiter_html;