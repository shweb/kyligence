<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
Heading style
*/
$output .= $delimiter_html;
$output .= $subtitle_html;
$output .= $title_html;