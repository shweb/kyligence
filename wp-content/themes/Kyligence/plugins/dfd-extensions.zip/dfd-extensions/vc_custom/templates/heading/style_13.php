<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
Heading style
*/

$output .= '<div class="cover">';
$output .= $title_html;
$output .= $subtitle_html;
$output .= '</div>';
$output .= $delimiter_html;